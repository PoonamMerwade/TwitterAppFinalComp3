export class Tweet {
    tweetId!: number;
    username!: any;
    tweet!: string;
    date!:string;
}
